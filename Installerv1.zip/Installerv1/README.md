Tools yang berfungsi untuk otomatis 
menginstall berbagai Tools penting 
Termux 
Tools yang diinstall antara lain
-
python2 
python 
php 
pip 
python2-dev 
git 
ruby 
perl 
pip mechanize 
pip 
nano
figlet 
sh
toilet

untuk cara pemakaiannya
~
$pkg install git
$pkg install figlet
$git clone 
https://github.com/rnocry12/Installerv1
$cd Installerv1
$bash Installerv1.sh
